import { ArrowUp } from "lucide-react";
import { portfolioData } from "../data/portfolioData.js";

export default function Footer({ t, onBackToTop }) {
  return (
    <footer className={`border-t ${t.footerBg} py-8 px-5 sm:px-8`}>
      <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-4">
        <p className={`text-sm ${t.textMuted}`}>
          © {portfolioData.footerYear} {portfolioData.name}. All rights reserved.
        </p>
        <button
          onClick={onBackToTop}
          className={`flex items-center gap-1.5 text-sm font-medium ${t.textSecondary} transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 rounded px-2 py-1`}
        >
          <ArrowUp size={14} aria-hidden="true" />
          Back to top
        </button>
      </div>
    </footer>
  );
}

import { portfolioData } from "../data/portfolioData.js";
import { iconMap } from "./icons.js";
import Reveal from "./Reveal.jsx";
import NodeNetwork from "./NodeNetwork.jsx";

export default function About({ t, isDark }) {
  return (
    <section id="about" className="pt-28 pb-20 px-5 sm:px-8 max-w-6xl mx-auto scroll-mt-16">
      <Reveal>
        <p className={`text-sm font-medium ${t.textMuted} mb-2`}>{portfolioData.role}</p>
        <h1 className={`text-3xl sm:text-4xl font-semibold tracking-tight ${t.textPrimary} mb-10 max-w-2xl`}>
          Building with AI, one hackathon at a time.
        </h1>
      </Reveal>

      <div className="grid md:grid-cols-5 gap-10 items-start">
        <Reveal className="md:col-span-3">
          <div className={`space-y-4 leading-relaxed ${t.textSecondary} max-w-prose`}>
            {portfolioData.about.paragraphs.map((p, i) => (
              <p key={i}>{p}</p>
            ))}
          </div>
        </Reveal>

        <Reveal className="md:col-span-2">
          <div className={`rounded-2xl border ${t.surface} p-5 mb-5 h-56 flex items-center justify-center overflow-hidden`}>
            <div className="w-full h-full max-w-xs">
              <NodeNetwork isDark={isDark} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {portfolioData.stats.map((stat, i) => {
              const Icon = iconMap[stat.icon];
              return (
                <div key={i} className={`rounded-xl border ${t.surfaceAlt} p-4 flex flex-col gap-2`}>
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${t.iconWrap}`}>
                    <Icon size={16} className="text-cyan-400" aria-hidden="true" />
                  </div>
                  <span className={`text-sm font-medium ${t.textPrimary}`}>{stat.label}</span>
                </div>
              );
            })}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

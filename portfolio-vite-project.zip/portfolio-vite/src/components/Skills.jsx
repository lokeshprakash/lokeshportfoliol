import { portfolioData } from "../data/portfolioData.js";
import { iconMap } from "./icons.js";
import Reveal from "./Reveal.jsx";

export default function Skills({ t }) {
  return (
    <section id="skills" className="py-20 px-5 sm:px-8 max-w-6xl mx-auto scroll-mt-16">
      <Reveal>
        <h2 className={`text-2xl sm:text-3xl font-semibold tracking-tight ${t.textPrimary} mb-10`}>
          Technical Skills
        </h2>
      </Reveal>
      <Reveal>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {portfolioData.skills.map((skill, i) => {
            const Icon = iconMap[skill.icon];
            return (
              <div
                key={i}
                className={`group rounded-xl border ${t.chip} p-5 flex flex-col items-center gap-3 text-center transition-all duration-300 hover:-translate-y-1 hover:shadow-lg`}
              >
                <div className={`w-11 h-11 rounded-lg flex items-center justify-center ${t.iconWrap} transition-transform duration-300 group-hover:scale-110`}>
                  <Icon size={20} className="text-cyan-400" aria-hidden="true" />
                </div>
                <span className={`text-sm font-medium ${t.badgeText}`}>{skill.name}</span>
              </div>
            );
          })}
        </div>
      </Reveal>
    </section>
  );
}

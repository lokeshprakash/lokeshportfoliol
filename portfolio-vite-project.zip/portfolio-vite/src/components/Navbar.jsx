import { useState } from "react";
import { Menu, X, Sun, Moon, User, Layers, Trophy, Briefcase, Mail } from "lucide-react";
import { portfolioData } from "../data/portfolioData.js";

const navItems = [
  { id: "about", label: "About", icon: User },
  { id: "skills", label: "Skills", icon: Layers },
  { id: "hackathons", label: "Hackathons", icon: Trophy },
  { id: "experience", label: "Experience", icon: Briefcase },
  { id: "contact", label: "Contact", icon: Mail },
];

export default function Navbar({ t, isDark, toggleTheme, activeSection, onNavigate }) {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleClick = (id) => {
    onNavigate(id);
    setMenuOpen(false);
  };

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 backdrop-blur-md border-b ${t.navBg}`}>
      <nav className="max-w-6xl mx-auto px-5 sm:px-8 h-16 flex items-center justify-between">
        <button
          onClick={() => handleClick("top")}
          className={`font-semibold tracking-tight text-lg ${t.textPrimary} focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 rounded`}
          aria-label="Scroll to top"
        >
          {portfolioData.name}
        </button>

        <div className="hidden md:flex items-center gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = activeSection === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleClick(item.id)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-md text-sm font-medium transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 ${
                  active ? t.navActive : t.navInactive
                }`}
                aria-current={active ? "true" : undefined}
              >
                <Icon size={15} aria-hidden="true" />
                {item.label}
              </button>
            );
          })}
          <button
            onClick={toggleTheme}
            className={`ml-2 p-2 rounded-md ${t.toggleBg} transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400`}
            aria-label={isDark ? "Switch to light theme" : "Switch to dark theme"}
          >
            {isDark ? <Sun size={16} /> : <Moon size={16} />}
          </button>
        </div>

        <div className="flex md:hidden items-center gap-1">
          <button
            onClick={toggleTheme}
            className={`p-2 rounded-md ${t.toggleBg} transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400`}
            aria-label={isDark ? "Switch to light theme" : "Switch to dark theme"}
          >
            {isDark ? <Sun size={16} /> : <Moon size={16} />}
          </button>
          <button
            onClick={() => setMenuOpen((o) => !o)}
            className={`p-2 rounded-md ${t.toggleBg} transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400`}
            aria-label={menuOpen ? "Close menu" : "Open menu"}
            aria-expanded={menuOpen}
          >
            {menuOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </nav>

      {menuOpen && (
        <div className={`md:hidden border-t ${t.border} ${t.navBg} backdrop-blur-md`}>
          <div className="flex flex-col px-5 py-3 gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleClick(item.id)}
                  className={`flex items-center gap-3 px-3 py-3 rounded-md text-base font-medium text-left transition-colors ${
                    active ? t.navActive : t.navInactive
                  }`}
                >
                  <Icon size={18} aria-hidden="true" />
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </header>
  );
}

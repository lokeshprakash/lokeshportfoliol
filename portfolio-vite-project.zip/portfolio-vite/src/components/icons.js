// Central icon registry so components never import icon libraries directly.
//
// Brand logos come from react-icons/si (Simple Icons) where an official
// logo actually exists. C and SQL don't have a single official brand mark
// (SQL is a language spec, not a product), so those use generic lucide
// icons instead of guessing at a logo.

import {
  SiPython,
  SiPandas,
  SiNumpy,
  SiOpenjdk,
  SiMongodb,
  SiMicrosoftexcel,
} from "react-icons/si";
import {
  GraduationCap,
  Trophy,
  Users,
  Brain,
  Sprout,
  Compass,
  Share2,
  TrendingUp,
  Cpu,
  Database,
} from "lucide-react";

export const iconMap = {
  // stats / timeline
  GraduationCap,
  Trophy,
  Users,
  Brain,
  Sprout,
  Compass,
  Share2,
  TrendingUp,

  // skills — brand logos where they exist
  Python: SiPython,
  Pandas: SiPandas,
  NumPy: SiNumpy,
  Java: SiOpenjdk, // Java itself has no standalone Simple Icons logo; OpenJDK is the closest official mark
  MongoDB: SiMongodb,
  Excel: SiMicrosoftexcel,

  // skills — no official single-brand logo, generic icon instead
  C: Cpu,
  SQL: Database,
};

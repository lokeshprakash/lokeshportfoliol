import { Mail, Instagram, Linkedin, ExternalLink } from "lucide-react";
import { portfolioData } from "../data/portfolioData.js";
import Reveal from "./Reveal.jsx";

export default function Contact({ t }) {
  const { message, email } = portfolioData.contact;
  return (
    <section id="contact" className="py-24 px-5 sm:px-8 max-w-6xl mx-auto scroll-mt-16">
      <Reveal className="max-w-xl">
        <h2 className={`text-2xl sm:text-3xl font-semibold tracking-tight ${t.textPrimary} mb-3`}>Let's Connect</h2>
        <p className={`text-base leading-relaxed ${t.textSecondary} mb-8`}>{message}</p>

        <a
          href={`mailto:${email}`}
          className={`inline-flex items-center gap-3 rounded-xl border ${t.chip} px-5 py-4 text-base font-medium ${t.textPrimary} transition-all hover:-translate-y-0.5 hover:shadow-lg mb-8 focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400`}
          aria-label={`Send an email to ${email}`}
        >
          <Mail size={18} className="text-cyan-400" aria-hidden="true" />
          {email}
        </a>

        <div className="flex items-center gap-3">
          <a
            href={`https://instagram.com/${portfolioData.social.instagram}`}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Visit Instagram profile (opens in a new tab)"
            className={`w-11 h-11 rounded-lg border ${t.chip} flex items-center justify-center transition-all hover:-translate-y-0.5 hover:shadow-md focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400`}
          >
            <Instagram size={18} className={t.textSecondary} aria-hidden="true" />
          </a>
          <a
            href={`https://linkedin.com/in/${portfolioData.social.linkedin}`}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Visit LinkedIn profile (opens in a new tab)"
            className={`w-11 h-11 rounded-lg border ${t.chip} flex items-center justify-center transition-all hover:-translate-y-0.5 hover:shadow-md focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400`}
          >
            <Linkedin size={18} className={t.textSecondary} aria-hidden="true" />
          </a>
          <span className={`text-xs ${t.textMuted} flex items-center gap-1`}>
            <ExternalLink size={12} aria-hidden="true" />
            opens in a new tab
          </span>
        </div>
      </Reveal>
    </section>
  );
}

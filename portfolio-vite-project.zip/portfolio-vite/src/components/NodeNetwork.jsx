export default function NodeNetwork({ isDark }) {
  const nodes = [
    { x: 40, y: 40 }, { x: 140, y: 30 }, { x: 230, y: 70 },
    { x: 70, y: 130 }, { x: 180, y: 150 }, { x: 260, y: 190 },
    { x: 30, y: 220 }, { x: 150, y: 240 },
  ];
  const edges = [
    [0, 1], [1, 2], [0, 3], [1, 4], [2, 4], [3, 4], [3, 6], [4, 5], [4, 7], [6, 7],
  ];
  const lineColor = isDark ? "#334155" : "#CBD5E1";
  const nodeColor = isDark ? "#22D3EE" : "#6366F1";

  return (
    <svg
      viewBox="0 0 300 280"
      className="w-full h-full"
      role="img"
      aria-label="Decorative network graphic representing AI and machine learning"
    >
      <style>{`
        @keyframes nodePulse {
          0%, 100% { opacity: 0.55; r: 4; }
          50% { opacity: 1; r: 6; }
        }
        .node-pulse { animation: nodePulse 3.4s ease-in-out infinite; }
        @media (prefers-reduced-motion: reduce) {
          .node-pulse { animation: none; opacity: 0.9; }
        }
      `}</style>
      {edges.map(([a, b], i) => (
        <line
          key={i}
          x1={nodes[a].x}
          y1={nodes[a].y}
          x2={nodes[b].x}
          y2={nodes[b].y}
          stroke={lineColor}
          strokeWidth="1"
        />
      ))}
      {nodes.map((n, i) => (
        <circle
          key={i}
          cx={n.x}
          cy={n.y}
          r="4"
          fill={nodeColor}
          className="node-pulse"
          style={{ animationDelay: `${i * 0.35}s` }}
        />
      ))}
    </svg>
  );
}

import { Briefcase, Calendar } from "lucide-react";
import { portfolioData } from "../data/portfolioData.js";

export default function Experience({ t }) {
  return (
    <section id="experience" className="py-20 px-5 sm:px-8 max-w-6xl mx-auto scroll-mt-16">
      <div className="mb-10">
        <h2 className={`text-2xl sm:text-3xl font-semibold tracking-tight ${t.textPrimary}`}>Experience</h2>
      </div>
      <div className="space-y-5 max-w-3xl">
        {portfolioData.experience.map((job, i) => (
          <div key={i} className={`rounded-2xl border ${t.surface} p-6 flex gap-4`}>
            <div className={`flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center ${t.iconWrap}`}>
              <Briefcase size={18} className="text-cyan-400" aria-hidden="true" />
            </div>
            <div className="flex-1">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
                <h3 className={`text-base font-semibold ${t.textPrimary}`}>{job.title}</h3>
                <span
                  className={`flex items-center gap-1 text-xs font-medium px-2.5 py-1 rounded-full ${
                    job.current ? t.currentBadge : `${t.surfaceAlt} border ${t.border} ${t.textMuted}`
                  }`}
                >
                  <Calendar size={12} aria-hidden="true" />
                  {job.duration}
                </span>
              </div>
              <p className={`text-sm ${t.textMuted} mb-3`}>{job.org}</p>
              {job.points.length > 0 && (
                <ul className={`space-y-1.5 text-sm leading-relaxed ${t.textSecondary} list-disc pl-4`}>
                  {job.points.map((pt, j) => (
                    <li key={j}>{pt}</li>
                  ))}
                </ul>
              )}
              {job.current && job.points.length === 0 && (
                <p className={`text-sm italic ${t.textMuted}`}>More details coming soon.</p>
              )}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

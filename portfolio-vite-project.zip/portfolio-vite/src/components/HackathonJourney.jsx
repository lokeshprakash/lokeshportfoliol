import { Quote } from "lucide-react";
import { portfolioData } from "../data/portfolioData.js";
import { iconMap } from "./icons.js";
import Reveal from "./Reveal.jsx";

export default function HackathonJourney({ t, isDark }) {
  const progressionTints = isDark
    ? ["bg-slate-700", "bg-slate-600", "bg-indigo-700", "bg-indigo-500", "bg-cyan-400"]
    : ["bg-slate-300", "bg-slate-400", "bg-indigo-300", "bg-indigo-500", "bg-cyan-500"];

  return (
    <section id="hackathons" className="py-20 px-5 sm:px-8 max-w-6xl mx-auto scroll-mt-16">
      <Reveal>
        <h2 className={`text-2xl sm:text-3xl font-semibold tracking-tight ${t.textPrimary} mb-3`}>
          My Hackathon Journey
        </h2>
        <p className={`text-sm ${t.textMuted} mb-12`}>Spark Tank → Smart Ability → Phoenix → ZEAI → SIH</p>
      </Reveal>

      <div className="relative">
        <div
          className={`absolute left-5 top-2 bottom-2 w-px bg-gradient-to-b ${
            isDark ? "from-slate-700 via-indigo-600 to-cyan-400" : "from-slate-300 via-indigo-400 to-cyan-500"
          }`}
          aria-hidden="true"
        />
        <ol className="space-y-10">
          {portfolioData.hackathons.map((item, i) => {
            const Icon = iconMap[item.icon];
            return (
              <li key={i}>
                <Reveal>
                  <div className="flex gap-5">
                    <div
                      className={`relative z-10 flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${progressionTints[i]}`}
                    >
                      <Icon size={17} className={isDark ? "text-slate-100" : "text-white"} aria-hidden="true" />
                    </div>
                    <div className={`flex-1 rounded-2xl border ${t.surface} p-5 sm:p-6`}>
                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mb-2">
                        <h3 className={`text-lg font-semibold ${t.textPrimary}`}>{item.title}</h3>
                        <span className={`text-xs font-medium px-2 py-0.5 rounded-full border ${t.border} ${t.textMuted}`}>
                          {item.stage}
                        </span>
                      </div>
                      <p className={`text-sm leading-relaxed ${t.textSecondary} mb-3 max-w-prose`}>
                        {item.description}
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {item.points.map((point, j) => (
                          <span
                            key={j}
                            className={`text-xs px-2.5 py-1 rounded-md ${t.surfaceAlt} border ${t.border} ${t.textSecondary}`}
                          >
                            {point}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </Reveal>
              </li>
            );
          })}
        </ol>
      </div>

      <Reveal className="mt-14 max-w-2xl">
        <p className={`text-base leading-relaxed ${t.textSecondary} mb-8`}>{portfolioData.hackathonClosing}</p>
        <blockquote className={`border-l-2 ${isDark ? "border-cyan-400" : "border-indigo-500"} pl-5`}>
          <Quote size={20} className={isDark ? "text-cyan-400 mb-2" : "text-indigo-500 mb-2"} aria-hidden="true" />
          <p className={`text-xl sm:text-2xl font-medium ${t.textPrimary} leading-snug`}>
            {portfolioData.hackathonQuote}
          </p>
        </blockquote>
        <p className={`text-sm leading-relaxed ${t.textMuted} mt-6`}>{portfolioData.hackathonFooterNote}</p>
      </Reveal>
    </section>
  );
}

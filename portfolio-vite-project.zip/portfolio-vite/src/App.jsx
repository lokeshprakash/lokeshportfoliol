import { useCallback, useEffect, useState } from "react";
import { getTheme } from "./theme.js";
import Navbar from "./components/Navbar.jsx";
import About from "./components/About.jsx";
import Skills from "./components/Skills.jsx";
import HackathonJourney from "./components/HackathonJourney.jsx";
import Experience from "./components/Experience.jsx";
import Contact from "./components/Contact.jsx";
import Footer from "./components/Footer.jsx";

const sectionIds = ["about", "skills", "hackathons", "experience", "contact"];

export default function App() {
  const [isDark, setIsDark] = useState(true);
  const [activeSection, setActiveSection] = useState("about");
  const t = getTheme(isDark);

  const scrollTo = useCallback((id) => {
    if (id === "top") {
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActiveSection(entry.target.id);
        });
      },
      { rootMargin: "-45% 0px -45% 0px", threshold: 0 }
    );
    sectionIds.forEach((id) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  return (
    <div className={`min-h-screen ${t.page} transition-colors duration-300`}>
      <Navbar
        t={t}
        isDark={isDark}
        toggleTheme={() => setIsDark((d) => !d)}
        activeSection={activeSection}
        onNavigate={scrollTo}
      />
      <main>
        <About t={t} isDark={isDark} />
        <Skills t={t} />
        <HackathonJourney t={t} isDark={isDark} />
        <Experience t={t} />
        <Contact t={t} />
      </main>
      <Footer t={t} onBackToTop={() => scrollTo("top")} />
    </div>
  );
}

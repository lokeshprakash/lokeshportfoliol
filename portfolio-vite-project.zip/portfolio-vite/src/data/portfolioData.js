// ---------------------------------------------------------------------
// Edit everything about the portfolio's content here.
// Components read from this file — no content lives inside components.
// ---------------------------------------------------------------------

export const portfolioData = {
  name: "Lokesh S",
  role: "AI & Data Science Student",

  about: {
    paragraphs: [
      "Hi, I'm Lokesh S., a B.Tech student specializing in Artificial Intelligence and Data Science at Rajalakshmi Engineering College, Chennai.",
      "I'm passionate about Artificial Intelligence, Machine Learning, Data Science, and software development. I enjoy turning ideas into practical projects and exploring how technology can solve real-world problems.",
      "I have worked on several projects and hackathons, including AI-powered systems, smart parking solutions, civic technology, and Bitcoin transaction monitoring using Machine Learning. These experiences have helped me develop skills in Python, Java, C, SQL, Pandas, NumPy, Machine Learning, and AI-based problem solving.",
      "Hackathons have played an important role in my learning journey. I enjoy working in teams, taking responsibility, solving problems under pressure, and learning from every experience — even when the result isn't what I expected.",
      "Recently, I also reached the finals of the ZEAI hackathon, which gave me valuable experience in building and presenting an AI-based solution.",
    ],
  },

  // icon values reference the `iconMap` in src/components/icons.js
  stats: [
    { label: "B.Tech — AI & Data Science", icon: "GraduationCap" },
    { label: "5 Hackathons", icon: "Trophy" },
    { label: "Team Leadership", icon: "Users" },
    { label: "ML Experience", icon: "Brain" },
  ],

  skills: [
    { name: "Python", icon: "Python" },
    { name: "Pandas", icon: "Pandas" },
    { name: "NumPy", icon: "NumPy" },
    { name: "Java", icon: "Java" },
    { name: "C", icon: "C" },
    { name: "SQL", icon: "SQL" },
    { name: "MongoDB", icon: "MongoDB" },
    { name: "Microsoft Excel", icon: "Excel" },
  ],

  hackathons: [
    {
      title: "Spark Tank",
      stage: "Beginner",
      icon: "Sprout",
      points: ["Smart Parking System", "IoT Sensors"],
      description:
        "My hackathon journey started here, with zero hackathon experience. My team developed a Smart Parking System using IoT sensors. Although we didn't win, it taught me the basics of teamwork, problem-solving, pitching, and learning from failure.",
    },
    {
      title: "Smart Ability",
      stage: "Developer",
      icon: "Compass",
      points: ["Real-world problem solving", "Practical solutions"],
      description:
        "Here I learned to identify real-world problems, build practical solutions, and present ideas with more confidence.",
    },
    {
      title: "Phoenix Hackathon",
      stage: "Developer",
      icon: "Share2",
      points: ["ARAM", "AI-powered civic governance", "Multi-agent systems"],
      description:
        "I worked on ARAM, an AI-powered civic governance platform. This helped me explore AI, multi-agent systems, and civic technology while improving my teamwork and project-building skills.",
    },
    {
      title: "ZEAI Hackathon",
      stage: "Team Leader",
      icon: "Users",
      points: ["Team Hustlers", "Team Lead", "AI solution"],
      description:
        "I took on the role of Team Lead with Team Hustlers. I gained more confidence in planning, development, pitching, and leading a team, and reached the finals.",
    },
    {
      title: "Smart India Hackathon",
      stage: "ML Contributor",
      icon: "TrendingUp",
      points: ["NTRO", "Bitcoin Transaction Monitoring", "Isolation Forest", "XGBoost"],
      description:
        "I worked on an AI-powered Bitcoin Transaction Monitoring System for NTRO. As part of the ML team, I worked with Isolation Forest and XGBoost for anomaly detection.",
    },
  ],

  hackathonClosing:
    "Each hackathon helped me grow — from having zero experience to building, leading, and solving real-world problems using AI/ML.",
  hackathonQuote:
    "The journey is not about winning every time; it's about becoming better every time.",
  hackathonFooterNote:
    "I may not have won every hackathon, but every failure gave me experience, every project taught me something new, and every competition made me better.",

  experience: [
    {
      org: "Confederation of Indian Industry (CII) — Southern Region",
      title: "Internship",
      duration: "15-Day Internship",
      current: false,
      points: [
        "Gained practical exposure to the IT industry and corporate work environment.",
        "Developed an understanding of organizational operations and professional workflows.",
        "Strengthened communication, teamwork, and professional skills through workplace interactions.",
      ],
    },
    {
      org: "ARQ Club — Rajalakshmi Engineering College",
      title: "Cloud Computing Associate",
      duration: "Currently Working",
      current: true,
      points: [],
    },
  ],

  contact: {
    message:
      "Interested in collaborating, discussing technology, or connecting professionally? Feel free to reach out.",
    // NOTE: fixed from the original "gamil.com" typo — update here if this changes.
    email: "lokkie@gmail.com",
  },

  // Placeholder links — replace with your real profile URLs.
  social: {
    instagram: "dfdgfgdgdgdf",
    linkedin: "fdfeg",
  },

  footerYear: 2026,
};

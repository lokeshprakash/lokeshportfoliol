export function getTheme(isDark) {
  return isDark
    ? {
        page: "bg-slate-950 text-slate-100",
        navBg: "bg-slate-950/80 border-slate-800",
        navActive: "text-cyan-300",
        navInactive: "text-slate-400 hover:text-slate-100",
        surface: "bg-slate-900/60 border-slate-800",
        surfaceAlt: "bg-slate-900/40 border-slate-800",
        textPrimary: "text-slate-100",
        textSecondary: "text-slate-400",
        textMuted: "text-slate-500",
        border: "border-slate-800",
        chip: "bg-slate-900/70 border-slate-800 hover:border-cyan-800",
        badgeText: "text-slate-200",
        iconWrap: "bg-slate-800/80",
        footerBg: "bg-slate-950 border-slate-800",
        toggleBg: "bg-slate-800 hover:bg-slate-700",
        currentBadge: "bg-cyan-500/15 text-cyan-300",
      }
    : {
        page: "bg-white text-slate-900",
        navBg: "bg-white/85 border-slate-200",
        navActive: "text-indigo-600",
        navInactive: "text-slate-500 hover:text-slate-900",
        surface: "bg-white border-slate-200",
        surfaceAlt: "bg-slate-50 border-slate-200",
        textPrimary: "text-slate-900",
        textSecondary: "text-slate-600",
        textMuted: "text-slate-500",
        border: "border-slate-200",
        chip: "bg-white border-slate-200 hover:border-indigo-300",
        badgeText: "text-slate-700",
        iconWrap: "bg-slate-100",
        footerBg: "bg-white border-slate-200",
        toggleBg: "bg-slate-200 hover:bg-slate-300",
        currentBadge: "bg-indigo-50 text-indigo-600",
      };
}
